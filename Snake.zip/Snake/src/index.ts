//引入样式
import './style/index.less';
import GameControl from "./modules/GameControl";
const gameControl=new GameControl();//游戏 开始
// setInterval(()=>{
//     console.log(gameControl.direction);
// },1000);


//console.log("自动更新中·····");

// import Food from "./modules/Food";
// import ScorePanel from "./modules/ScorePanel";
// import Snake from "./modules/Snake";


//测试代码
// const  food=new Food();
// food.change();
// console.log(food.X);



// const scorePanel=new ScorePanel(100,2);
// //测试
// for(let i=0;i<200;i++){
//     scorePanel.addScore();
//
// }
