//定义Snake类
class Snake{
    //蛇的容器
    element:HTMLElement;
    //表示蛇头的元素
    head:HTMLElement;
    //蛇的身体（包括蛇头）
    bodies:HTMLCollection;// 它是一个集合
    constructor() {
        //#snake>div:#snake中的第一个div，                        断言为HTMLElement类型
        this.head=document.querySelector('#snake>div') as HTMLElement;
        //获取蛇的容器
        this.element=document.getElementById('snake')!;

        //获取身体
        this.bodies=document.getElementById('snake')!.getElementsByTagName('div');
    }
    //获取蛇头坐标X
    get X(){
        return this.head.offsetLeft;
    }
    //获取蛇头坐标Y
    get Y(){
        return this.head.offsetTop;
    }
    //设置蛇头坐标X
    set X(value:number){
        //如果新值与旧值相等,则直接返回，不必修改
        if(this.X===value){
            return;
        }
        //X的合法范围为0~290
        if(value<0||value>290){
            //如果进去判断则说明蛇死了,抛出异常
            throw new Error('蛇撞墙了！');

        }
        //修改X时，是在修改水平坐标，蛇在左右移动
        //当蛇在向左走时，不能向右掉头，反之亦然
        //水平方向判断：有身体1且 头部等于身体1时，说明掉头了
        if(this.bodies[1]&&(this.bodies[1] as  HTMLElement).offsetLeft===value){
            //console.log("水平方向掉头了");
            //已经判定为掉头了
            if(value>this.X){
                //value大于this.X（原值），说明向右掉头了，应该让蛇继续向左走
                value=this.X-10;
            }else {
                //继续向右走
                value=this.X+10;
            }

        }
        this.moveBody();
        this.head.style.left=value+'px';
        //检查有没有撞到自己
        this.checkHeadBody();
    }
    //设置蛇头坐标Y
    set Y(value:number){
        //如果新值与旧值相等,则直接返回，不必修改
        if(this.Y===value){
            return;
        }
        //Y的合法范围为0~290
        if(value<0||value>290){
            //如果进去判断则说明蛇死了
            throw new Error('蛇撞墙了！');

        }
        //修改Y时，是在修改垂直坐标，蛇在上下移动
        //当蛇在向上走时，不能向下掉头，反之亦然
        //垂直方向判断：有身体1且 头部等于身体1时，说明掉头了
        if(this.bodies[1]&&(this.bodies[1] as  HTMLElement).offsetTop===value){
            //console.log("垂直方向掉头了");
            //已经判定为掉头了
            if(value>this.Y){
                //value大于this.Y（原值），说明向下掉头了，应该让蛇继续向上走
                value=this.Y-10;
            }else {
                //继续向下走
                value=this.Y+10;
            }

        }
        this.moveBody();
        this.head.style.top=value+'px';
        //检查有没有撞到自己
        this.checkHeadBody();
    }

    //给蛇增加身体，就是给element 增加一个div
    addBody(){
        //给element 增加一个div
                    //insertAdjacentHTML:通过插入html代码，添加元素
                    //第一个参数是插入位置beforeend表示在结束标签之前
                                    // ，第二个参数是
        this.element.insertAdjacentHTML('beforeend',"<div></div>");
    }
    ///添加一个蛇身体运动的方法
    moveBody(){
        //移动就是：后边的走到前边的位置
        //一定要从后往前改
        //即第4节移动到第3节的位置，
        //                  第3节移动到第2节的位置，
        //                                   第2节移动到蛇头的位置，
        //                                                          第1节移动到对应的位置，
        for(let i=this.bodies.length-1;i>0;i--){
            //获取前边身体的位置
            let X=(this.bodies[i-1] as HTMLElement).offsetLeft;  // as HTMLElement是断言
            let Y=(this.bodies[i-1] as HTMLElement).offsetTop;

            //将值赋值给当前节
            (this.bodies[i] as HTMLElement).style.left=X+'px';
            (this.bodies[i] as HTMLElement).style.top=Y+'px';

        }
    }
    //检查头部与身体是否相撞
    checkHeadBody(){
        //获取所有的身体，检查其是否和蛇头坐标发生重叠
        for(let i=1;i<this.bodies.length;i++){
            let bd=this.bodies[i] as HTMLElement;
            if(this.X===bd.offsetLeft && this.Y===bd.offsetTop){
                //进入判断，说明蛇头撞到了身体
                //console.log('蛇头撞到了身体');
                //抛出异常
                throw new Error("蛇头撞到了身体~~");

            }

        }

    }



}
export default Snake;