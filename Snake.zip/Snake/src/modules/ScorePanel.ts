//定义表示记分牌的类
import Food from "./Food";

class ScorePanel{
    //score level 用来记录分数和等级
    score=0;
    level=1;

    //分数和等级所在的元素，他们在构造函数中初始化
    scoreEle:HTMLElement;
    levelEle:HTMLElement;

    //设置最高等级（使用变量，易于程序扩展，维护）
    maxLevel:number;
    //设置一个变量，表示多少分升一级
    upScore:number;

    constructor(maxLevel:number=10,upScore:number=10) {  //默认值是10
        this.scoreEle=document.getElementById("score")!;
        this.levelEle=document.getElementById("level")!;
        this.maxLevel=maxLevel;
        this.upScore=upScore;
    }
    //设置一个加分的方法
    addScore(){
        //使分数自增
        this.score=this.score+1;
        this.scoreEle.innerHTML=this.score+"";//整数加字符串  类型转换

        //判断分数是多少，每加upScore分，level加1
        if(this.score%this.upScore===0){
            this.levelUp();

        }
    }
    //设置一个增加等级的方法
    levelUp(){
        //当等级小于maxLevel时使等级自增
        if(this.level<this.maxLevel){
            this.level=this.level+1;
            this.levelEle.innerHTML= this.level+"";//整数加字符串  类型转换
        }
    }
}

export default ScorePanel;